package dev.vhscam;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.client.event.RenderHandEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

public class ClientEvents {
    public static final String CAT = "key.category.vhscam";
    public static final KeyMapping TOGGLE = new KeyMapping("key.vhscam.toggle", GLFW.GLFW_KEY_V, CAT);
    public static final KeyMapping REC    = new KeyMapping("key.vhscam.rec", GLFW.GLFW_KEY_R, CAT);
    public static final KeyMapping ZOOM_IN  = new KeyMapping("key.vhscam.zoom_in", GLFW.GLFW_KEY_UP, CAT);
    public static final KeyMapping ZOOM_OUT = new KeyMapping("key.vhscam.zoom_out", GLFW.GLFW_KEY_DOWN, CAT);
    public static final KeyMapping TAPE   = new KeyMapping("key.vhscam.tape", GLFW.GLFW_KEY_B, CAT);
    public static final KeyMapping SPEED  = new KeyMapping("key.vhscam.speed", GLFW.GLFW_KEY_N, CAT);

    static boolean holdingCamera(Player p) {
        Item it = VhsCam.CAMCORDER.get();
        return p.getMainHandItem().is(it) || p.getOffhandItem().is(it);
    }

    @Mod.EventBusSubscriber(modid = VhsCam.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static class ModBus {
        @SubscribeEvent
        public static void onKeys(RegisterKeyMappingsEvent e) {
            e.register(TOGGLE);
            e.register(REC);
            e.register(ZOOM_IN);
            e.register(ZOOM_OUT);
            e.register(TAPE);
            e.register(SPEED);
        }
    }

    @Mod.EventBusSubscriber(modid = VhsCam.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
    public static class ForgeBus {
        private static boolean prevSneak = false;
        private static boolean wasGround = true;
        private static double prevVy = 0;
        private static long lastActionMs = 0;
        private static final float[] ZOOM_STEPS = {1f, 2f, 4f, 8f};

        @SubscribeEvent
        public static void onTick(TickEvent.ClientTickEvent e) {
            if (e.phase != TickEvent.Phase.END) return;
            Minecraft mc = Minecraft.getInstance();
            Player p = mc.player;
            if (p == null) { CamState.lower(); return; }

            boolean holding = holdingCamera(p);

            // landing jolt
            boolean g = p.isOnGround();
            if (CamState.active && g && !wasGround && prevVy < -0.3) {
                CamState.jolt = (float) Math.min(4.0, -prevVy * 4.0);
            }
            wasGround = g;
            prevVy = p.getDeltaMovement().y;

            // consome as teclas sempre (evita acumular cliques)
            boolean tog = false, rec = false, tape = false, speed = false;
            while (TOGGLE.consumeClick()) tog = true;
            while (REC.consumeClick()) rec = true;
            while (TAPE.consumeClick()) tape = true;
            while (SPEED.consumeClick()) speed = true;

            if (!holding) {
                if (CamState.active) CamState.lower();
                prevSneak = p.isShiftKeyDown();
                return;
            }

            if (tog) { if (CamState.active) CamState.lower(); else CamState.raise(); }

            // agachar abaixa a camera (util no toque)
            boolean sneak = p.isShiftKeyDown();
            if (CamState.active && sneak && !prevSneak) CamState.lower();
            prevSneak = sneak;

            if (CamState.active) {
                if (rec) CamState.toggleRec();
                if (tape && !CamState.recording) {
                    CamState.tape = (char) (CamState.tape >= 'D' ? 'A' : CamState.tape + 1);
                    CamState.recAccumMs = 0;
                }
                if (speed) CamState.longPlay = !CamState.longPlay;
                if (ZOOM_IN.isDown())  CamState.targetZoom = Math.min(CamState.MAX_ZOOM, CamState.targetZoom + 0.06f);
                if (ZOOM_OUT.isDown()) CamState.targetZoom = Math.max(1.0f, CamState.targetZoom - 0.06f);
                CamState.zoom += (CamState.targetZoom - CamState.zoom) * 0.25f;
            }
        }

        // Clique direito = erguer / gravar. Clique esquerdo (com a camera erguida) = zoom em passos.
        @SubscribeEvent
        public static void onClick(InputEvent.InteractionKeyMappingTriggered e) {
            Minecraft mc = Minecraft.getInstance();
            Player p = mc.player;
            if (p == null || mc.screen != null || !holdingCamera(p)) return;

            long now = System.currentTimeMillis();
            if (e.isUseItem()) {
                if (now - lastActionMs > 300) {
                    lastActionMs = now;
                    if (!CamState.active) CamState.raise();
                    else CamState.toggleRec();
                }
                e.setCanceled(true);
                e.setSwingHand(false);
            } else if (e.isAttack() && CamState.active) {
                if (now - lastActionMs > 300) {
                    lastActionMs = now;
                    float cur = CamState.targetZoom;
                    float next = ZOOM_STEPS[0];
                    for (float z : ZOOM_STEPS) { if (z > cur + 0.1f) { next = z; break; } }
                    CamState.targetZoom = next;
                }
                e.setCanceled(true);
                e.setSwingHand(false);
            }
        }

        // Sem mao na tela: quem segura a camera e o personagem
        @SubscribeEvent
        public static void onHand(RenderHandEvent e) {
            if (CamState.active) e.setCanceled(true);
        }

        @SubscribeEvent
        public static void onGui(RenderGuiEvent.Pre e) {
            if (!CamState.active) return;
            VhsOverlay.render(e.getGuiGraphics());
            e.setCanceled(true);
        }

        @SubscribeEvent
        public static void onFov(ViewportEvent.ComputeFov e) {
            if (CamState.active) e.setFOV(e.getFOV() / CamState.zoom);
        }

        // Movimento de camera na mao: inercia, respiracao, passos, pulo/queda
        @SubscribeEvent
        public static void onAngles(ViewportEvent.ComputeCameraAngles e) {
            if (!CamState.active) { CamState.lagInit = false; CamState.lastNs = 0; return; }
            Minecraft mc = Minecraft.getInstance();
            Player p = mc.player;
            if (p == null) return;

            long nowNs = System.nanoTime();
            double dt = CamState.lastNs == 0 ? 0.016 : Math.min(0.1, (nowNs - CamState.lastNs) / 1e9);
            CamState.lastNs = nowNs;
            double t = nowNs / 1e9;

            float yaw = e.getYaw(), pitch = e.getPitch();
            if (!CamState.lagInit) { CamState.lagYaw = yaw; CamState.lagPitch = pitch; CamState.lagInit = true; }

            // inercia: a camera "atrasa" um pouco ao girar
            double k = 1 - Math.exp(-dt * 9);
            CamState.lagYaw += Mth.wrapDegrees(yaw - CamState.lagYaw) * k;
            CamState.lagPitch += (pitch - CamState.lagPitch) * k;
            float lagOffY = (float) Mth.clamp(Mth.wrapDegrees(CamState.lagYaw - yaw) * 0.7, -7, 7);
            float lagOffP = (float) Mth.clamp((CamState.lagPitch - pitch) * 0.7, -7, 7);

            // passos
            Vec3 v = p.getDeltaMovement();
            double sp = Math.sqrt(v.x * v.x + v.z * v.z);
            float amp = (float) Math.min(1.5, sp / 0.1);
            if (!p.isOnGround()) amp *= 0.3f;
            double phase = p.walkDist * 2.4;
            float bobP = (float) (Math.abs(Math.sin(phase)) * 1.2 * amp);
            float bobY = (float) (Math.sin(phase) * 0.7 * amp);
            float bobR = (float) (Math.cos(phase) * 1.0 * amp);

            // tremor de mao e respiracao
            float dY = (float) (Math.sin(t * 0.9) * 0.25 + Math.sin(t * 2.3 + 1.1) * 0.12);
            float dP = (float) (Math.sin(t * 1.1 + 0.5) * 0.2 + Math.sin(t * 3.1) * 0.07 + Math.sin(t * 1.7) * 0.1);
            float dR = (float) (Math.sin(t * 0.7 + 2.0) * 0.25);

            CamState.jolt *= (float) Math.exp(-dt * 6);

            e.setYaw(yaw + lagOffY + bobY + dY);
            e.setPitch(pitch + lagOffP + bobP + dP + CamState.jolt);
            e.setRoll(e.getRoll() + bobR + dR + lagOffY * 0.3f);
        }
    }
}
