# VHS Viewfinder (Forge 1.20.1 / 47.x)
Item: vhscam:camcorder (aba Ferramentas do criativo, ou /give @s vhscam:camcorder).
Segure a camera: clique direito = erguer; de novo = gravar/standby; clique esquerdo (erguida) = zoom 1x/2x/4x/8x; agachar = abaixar.
Teclas opcionais: V erguer/abaixar | R gravar | Setas zoom | B fita | N SP/LP
Compilar: JDK 17 + Gradle 8.1.1-8.8 -> gradle build
